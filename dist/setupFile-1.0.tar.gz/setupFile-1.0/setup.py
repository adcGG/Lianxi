from distutils.core import setup
setup(
	name='setupFile',
	version='1.0',
	py_modules= ['setuoFile'],
)